#!/bin/bash

if [ "$1" = "-help" ]; then
	echo "--Uso ./backup_full.sh"
	echo "--Se debe ingresar por teclado el archivo que se quiere backupear y el destino del backup"
	echo "--Sintaxis : ./backup_full.sh [origen] [destino] "
	echo "--Se genera un archivo comprimido de tipo tar.gz con la fecha en la que se ejecuto el script"
	exit
fi

DIA=$(date +%Y%m%d)
HORA=$(date +%H:%M)
ORIGEN=$1
DESTINO=$2
NOMBRE=${ORIGEN##*/}
LOG="/var/log/backup.log"

if [[ "$DESTINO" == "/backup_dir" || "$DESTINO" == /backup_dir/* ]] ; then

	echo "OK: Fecha:$DIA -Hora:$HORA la particion donde guardar los backups es la correcta" >> $LOG
else 
	echo "ERROR: Fecha:$DIA - Hora:$HORA la particion donde guardar los backups debe ser /backup_dir" >> $LOG
	exit
fi

if [ -e "$ORIGEN" ] && [ -e "$DESTINO" ]; then
 BACKUP="${NOMBRE}_bkp_${DIA}.tar.gz"
 tar -czf "${DESTINO}/${BACKUP}" "${ORIGEN}"
 echo "Fecha:$DIA - Hora:$HORA Backup generado : ${BACKUP}" >> $LOG
else
 echo "ERROR: Fecha:$DIA - Hora:$HORA Ambos archivos deben existir para ejecutar el backup" >> $LOG
fi

