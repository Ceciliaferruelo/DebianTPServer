rm /etc/hash 
ls -l
reboot
history
shutdown now
hostnamectl set-hostname TPServer
sudo vim /etc/hosts
exit
lsb_release -a
cat /etc/debian_version
vim
vim /etc/apt/sources.list
aptupdate
apt update
vim /etc/apt/sources.list
apt update
ping 8.8.8.8
vim /etc/network/interfaces
netsat -natupl
netstat -natupl
ip -a
ifconfig
exit
shutdown -h
ping 8.8.8.8
ping 8.8.8.8
lspci|grep -i net
dmesg
ifconfig
vim /etc/network/interfaces
cat /sys/class/net
ls /sys/class/net
ls /sys/class/net
ping 8.8.8.8
iproute2
ip a
lspci | grep -i net
ifconfig -a
dmesg
dmesg > more
ls
ls -la
ip addr
vim /etc/network/interfaces
ping 8.8.8.8
ping 192.168.56.1
cat /etc/network/interfaces
ifup enp0s8
ping 8.8.8.8
ip addr
ifup enp0s3
ifup enpos8
ifup ep0s8
ifup enp0s8
ip route
ping -4 8.8.8.8
vim /etc/network/interfaces
ip addr
ip route
ping 8.8.8.8
ip link show enp0s3
dhclient -v enp0s3
ip route
ping -c 4 8.8.8.8
ping 8.8.8.8
ip route
ping google.com
apt update
cat /etc/apt/sources.list
vim /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt upgrade
apt update
apt full-upgrade
apt autoremove
lsb_release -a
apt install openssh-server
ls
cd /
ls
cd home/
ls
cd /root/
ls
tar xvzf Material_Adicional_TPVMCA.tar.gz 
ls -la /root/
ls -la /root/.ssh/
systemctl status ssh
vim /etc/ssh/sshd_config
ip addr
vim /etc/network/interfaces
ip addr
vim /etc/ssh/sshd_config
ip -4 addr
ip route
vim /etc/network/interfaces
ip link
ip addr
vim /etc/network/interfaces
ip -4 addr show enp0s8
cat /etc/network/interfaces.d/
grep -R "192.168.56.1" /etc/network/interfaces.d/
systemctl status networking
systemctl status NetworkManager
systemctl status NetworkManager.service 
systemctl status networking
ifquery enp0s8
ip addr
ifdown enp0s8
ip addr
ifup enp0s8
ip addr
passwd -S root
passwd
exit
exit
cd /
sshd -T | grep -E 'allowusers|denyusers|allowgroups|denygroups'
/usr/bin/sshd -T | grep -E 'allowusers|denyusers|allowgroups|denygroups'
/usr/sbin/sshd -T | grep -E 'allowusers|denyusers|allowgroups|denygroups'
ls /etc/ssh/sshd_config.d/
grep -rn root /etc/pam.d/sshd /etc/security/access.conf 2>/dev/null | grep -v '^`.*:#'
sed -n '99p' /etc/security/access.conf
grep -rn pam_access /etc/pam.d/
exit
exit
adduser prueba
ssh prueba@localhost
su - root
passwd -S root
vim /etc/ssh/sshd_config
grep "usePAM" /etc/ssh/sshd_config
grep "#usePAM" /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
vim /etc/network/interfaces
vim /etc/ssh/sshd_config
sshd -t
systemctl status ssh
passwd -S root
sshd -T | grep -E 'permitrootlogin|passwordauthentication|usepam'
grep -RniE 'permitrootlogin|passwordauthentication|usepam' /etc/ssh/
ssh root@localhost
ls -l /etc/passwd /etc/shadow /etc/group /etc/gshadow
apt install terminator
terminator
cat /etc/pam.d/sshd
dpkg --audit
dpkg --fix-broken install
su root
journalctl -n 40 --no-pager | grep -i -E 'sshd|pam'
passwd
su prueba
shundown -h
shutdown -h
ssh root@localhost
ls
cd .ssh/
ls
cat authorized_keys 
cd ..
ls
cd Material_Adicional_TPVMCA/
ls
cat clave_publica.pub 
ls
cd ../.ssh/
ls
rm authorized_keys 
ls
exit
echo como mierda hice eso
echo > @192.168.56.10
echo watafac >> @192.168.56.10
echo nose que hago root@192.168.56.10
mkdir directorioCreadoDesdeMiUbuntu
ls
cd Material_Adicional_TPVMCA/
ls
ls -la
index.php
ip addr
ls -la
cat index.php
apt install PHP
apt install php
apt install apache
apt install Apache
apt search apache
apt install apache2
apache
apache2
cd /
ls
cd bin/
ls
grep "apache"
grep "apache" /bin/
cd /sbin/
ls -la
apache2
./apache2
systemctl status apache
systemctl status apache2
cd /var
ls
cd www/
ls
cd html/
ls -la
cat index.html 
cd /
apt install php libapache2-mod-php
exit
hostname -i
hostnme -i
systemctl is-active apache2
hostname -I
php -v
apache2ctl -M | grep php
sshctl
hostnamectl
networkctl
systemctl restart apache2
systemctl status apache2
cp /root/inde.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
cd /var/www/html/
ls
mv /var/www/html/index.html /var/www/html/index.html.bak
ls
ls -la
apache2ctl configtest
chown root:www-data /var/www/html/index.php 
chown root:www-data /var/www/html/logo.png
ls -la
chmod 640 /var/www/html/logo.png
chmod 640 /var/www/html/index.php 
systemctl restart apache2
systemctl status apache2
curl http://localhost/
curl http://localhost/
exit
curl http://localhost/
php -v
apache2ctl -M | grep php
ls /etc/apache2/mods-enabled/ | grep php
systemctl status apache2
curl -i http://localhost/
tail -n 40 /var/log/apache2/error.log
apt install mariadb-server mariadb-client -y
systemctl status mariadb
mariadb
cd /root/Material_Adicional_TPVMCA/
ls
cat db.sql 
mariadb < /root/Material_Adicional_TPVMCA/db.sql 
mariadb
grep -inE 'CREATE DATABASE|USE |CREATE TABLE|INSERT INTO|CREATE USER' /root/db.sql
grep -inE 'CREATE DATABASE|USE |CREATE TABLE|INSERT INTO|CREATE USER' /root/Material_Adicional_TPVMCA/db.sql 
mariadb
curl -i http://localhost/
cp /root/Material_Adicional_TPVMCA/db.sql /var/www/html/
cd /var/www/html/
ls
curl -i http://localhost/
tail -n 40 /var/log/apache2/error.log
cd /
apt install php8.2-mysql -y
php -m | grep -i mysqli
apache2ctl -M | grep php
php -i | grep -i "mysqli support"
systemctl restart apache2
curl -i http://localhost/
ip route
EXIT
exit
ssh root@192.168.56.10
vim /etc/ssh/sshd_config
ls
ssh-copy-id root@192.168.56.10
ls
rm -rf directorioCreadoDesdeMiUbuntu/
rm -rf @192.168.56.10 
ls
hostname -i
netstat -natupl
curl http://localhost/
vim /etc/network/interfaces
cat /etc/network/interfaces
ifdown enp0s8
ifup enp0s8
ap addr
ip addr
ifdown enp0s8
ifup enp0s8
ip addr show enp0s8
ip route
cat /etc/network/interfaces
exit
ls
cd Material_Adicional_TPVMCA/
ls
cat clave_publica.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ssh root@localhost
exit
shutdown -h now
lsblk
cd /dev/sdc/
cd /dev/
ls
fdisk /dev/sdc
lsblk
fdisk /dev/sdc
fdisk /dev/sdc
lsblk
cd /
mkdir www_dir
mkdir backup_dir
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
df -h
mount /dev/sdc1 /www_dir/
df -h
mount /dev/sdc2 /backup_dir/
df -h
shutdown -h now
mount /dev/sdc1 /www.dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
lsblk
vim /etc/fstab
cat /etc/fstab
shutdown -h now
lsblk
cd /etc
ls
cat apache2/apache2.conf 
less < cat /etc/apache2/apache2.conf 
vim /etc/apache2/apache2.conf 
cd /
ls
ls /home/
ls /var/www/html/
vim /etc/apache2/sites-available/
ip addr
shutdown -r now
netstat -natupl
cd /var/www/html/
ls
cp /var/www/html/index.php /www_dir
cp /var/www/html/logo.php /www_dir
cp /var/www/html/logo.png /www_dir
apache2ctl configtest
systemctl reload apache2
apache2ctl configtest
apache2ctl configtest
ls -la
cd /
ls -la
cd /var/www/html/
ls -la
cd ..
ls -la
vim /etc/apache2/sites-available/
vim /etc/apache2/sites-available/
apache2ctl configtest
chmod 755 /www_dir
ls -la
cd ..
ls -la
cd /
ls -la
systemctl restart apache2
apache2ctl configtest
cd /www_dir/
ls
ls -la
chmod 655 index.php
chmod 655 logo.png
ls -la
tail -20 /var/log/apache2/error.log
tail -n 20 /var/log/apache2/error.log
vim /etc/apache2/sites-available/
apache2ctl configtest
systemctl restart apache2
cd /opt
ls
touch particion
ls
cat /proc/partitions >> /opt/particion
cat particion 
exit
shutdown -h now
vim script.sh
ls -la
chmod 655 script.sh 
./script.sh 
/opt/ /home/
./script.sh 
asdads lala
./script.sh /opt/ /home/
vim script.sh
./script.sh 
vim script.sh
./script.sh 
vim script.sh
./script.sh 
vim script.sh
cd ~
ls
mkdir DirectorioEjemploABackupear
cd DirectorioEjemploABackupear/
touch ArchivoEjemplo.txt
vim script.sh
ls -la
cd ..
ls
vim script.sh
./script.sh 
vim script.sh
./script.sh 
vim script.sh
./script.sh 
vim script.sh
./script.sh 
vim script.sh
./script.sh 
vim script.sh
./script.sh 
cd /
ls
cd /var/logs
cd /var/
ls
ls -la
cd ~
ls
./script.sh 
./script.sh 
ls -la
ls
/home/
cd /home/
ls
cat log_bkp_20261108.tar.gz 
rm -rf log_bkp_20261108.tar.gz 
ls -la
cd /root/
ls
mv /root/script.sh /opt/scripts
ls -la
ls
cd /opt/scripts
cd /opt
ls
cat scripts 
mv scripts backup_full.sh
ls
mkdir scripts
ls
mv backup_full.sh scripts/
ls
cd scripts/
ls
vim backup_full.sh 
vim backup_full.sh 
./backup_full.sh
./backup_full.sh -help
vim backup_full.sh 
./backup_full.sh -help
vim backup_full.sh 
./backup_full.sh 
 ls /backup_dir/
rm -rf /backup_dir/log_bkp_20261108.tar.gz 
vim backup_full.sh 
./backup_full.sh 
rm -rf /backup_dir/log_bkp_20261108.tar.gz 
 ls /backup_dir/
vim backup_full.sh 
./backup_full.sh 
rm -rf /backup_dir/log_bkp_20261108.tar.gz 
./backup_full.sh 
vim backup_full.sh 
./backup_full.sh 
./backup_full.sh exit
exit
cd /opt/
ls
cd scripts/
ld
ls
cat backup_full.sh 
exit
shutdown -h now
